package com.wipro.raemisclient.model;

import com.wipro.raemisclient.common.Constants;

public class GNodeB {

    private String name;
    private String plmn_id;
    private int gnb_id;
    private int tac;
    private String sctp_address;
    public static final String NMS_ID = "730451733424971667";

    public String getName() {
        return name;
    }

    public String getPlmn_id() {
        return plmn_id;
    }

    public int getGnb_id() {
        return gnb_id;
    }

    public int getTac() {
        return tac;
    }

    public String getSctp_address() {
        return sctp_address;
    }

    public GNodeB(String name, String plmn_id, int gnb_id, int tac, String sctp_address) {
        this.name = name;
        this.plmn_id = plmn_id;
        this.gnb_id = gnb_id;
        this.tac = tac;
        this.sctp_address = sctp_address;
    }
}
