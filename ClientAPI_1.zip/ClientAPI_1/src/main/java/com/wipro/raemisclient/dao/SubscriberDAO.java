package com.wipro.raemisclient.dao;

import com.wipro.raemisclient.model.Subscriber;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class SubscriberDAO implements DAOInterface<Subscriber> {

    private static final String DELETE_ALL_SUBSCRIBER_QUERY = "DELETE FROM subscriber";
    private static final String INSERT_SUBSCRIBER_QUERY = "INSERT INTO subscriber VALUES";
    private static final String VIEW_SUBSCRIBER_QUERY = "SELECT * FROM subscriber";
    private static Connection connection = null;

    public SubscriberDAO() throws NoSuchAlgorithmException, KeyManagementException {
        connection = DAOConnection.create_connection();
    }

    public void showAllRecords() throws SQLException {
        ResultSet resultSet;
        try (Statement statement = connection.createStatement()) {
            // Create and execute a SELECT SQL statement.
            resultSet = statement.executeQuery(VIEW_SUBSCRIBER_QUERY);
            // Print results from select statement
            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " " + resultSet.getString(3));
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void insertRecords(List<Subscriber> listOfData) throws SQLException {
        {
            int res;
            try (Statement statement = connection.createStatement()) {
                for (Subscriber data : listOfData) {
                    String queryParam = "(" + data.getId() + ", '" + data.getImsi() +
                            "', '" + data.getTmsi() + "', '" + data.getPtmsi() + "'," +
                            " '" + data.getImei() + "', '" + data.getMsisdn() + "', '" + data.getSip_client_attachment() + "'," +
                            " '" + data.getMno_attachment() + "', '" + data.getLocal_ps_attachment() + "'," +
                            " '" + data.getMno_ps_attachment() + "', '" + data.getDomain() + "', '" + data.getName() + "' , '" + Subscriber.getNmd_id() + "')";

                    res = statement.executeUpdate(INSERT_SUBSCRIBER_QUERY + queryParam);
                    if (res != 0) {
                        System.out.println("subscriber ----:" + data.getId() + " successfully polled.!");
                    }
                }
            } catch (SQLException e) {
                connection.close();
                e.printStackTrace();
            }
        }
    }

    public void deleteRecords() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(DELETE_ALL_SUBSCRIBER_QUERY);
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void pollRecords(List<Subscriber> listOfData) throws SQLException, InterruptedException {
        deleteRecords();
        Thread.sleep(300); // 300 millsec interval between delete and insert operation
        insertRecords(listOfData);
        //showAllRecords();
    }
}
