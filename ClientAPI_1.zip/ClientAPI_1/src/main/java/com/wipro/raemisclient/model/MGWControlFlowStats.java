package com.wipro.raemisclient.model;

public class MGWControlFlowStats {

    private String plmn_id;
    private int measurement_period;
    private int egress_octet_count;

    public String getPlmn_id() {
        return plmn_id;
    }

    public int getMeasurement_period() {
        return measurement_period;
    }

    public int getEgress_octet_count() {
        return egress_octet_count;
    }
}
