package com.wipro.raemisclient;

import com.wipro.raemisclient.common.Constants;
import com.wipro.raemisclient.services.*;
import com.wipro.raemisclient.session.HTTPSessionManager;

import java.util.Timer;
import java.util.TimerTask;

public class Main extends TimerTask {

    @Override
    public void run() {
        try {
            //startPolling();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void startPolling() throws Exception {
        new AlarmService().pull_AlarmDetailsFromRaemisAPI();
        new SubscriberService().pull_SubsriberDetailsFromRaemisAPI();
        new NetDeviceService().pull_NetDeviceDetailsFromRaemisAPI();

        //Throughput services
        new SubscriberFlowStatsService().pull_ThroughputFromRaemisAPI();
        new PDNFlowStatsService().pull_ThroughputFromRaemisAPI();
        new TACFlowStatsService().pull_ThroughputFromRaemisAPI();
    }

    public static void main(String[] args) {
        HTTPSessionManager.createSession();
        new Timer().schedule(new Main(), 0, Constants.POLL_INTERVAL);
    }
}