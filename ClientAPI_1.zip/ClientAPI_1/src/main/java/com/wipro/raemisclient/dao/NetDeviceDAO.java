package com.wipro.raemisclient.dao;

import com.wipro.raemisclient.model.NetDevice;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class NetDeviceDAO implements DAOInterface<NetDevice> {

    private static final String DELETE_ALL_NETDEVICE_QUERY = "DELETE FROM netdevice";
    private static final String INSERT_NETDEVICE_QUERY = "INSERT INTO netdevice VALUES";
    private static final String VIEW_NETDEVICE_QUERY = "SELECT * FROM netdevice";
    private static Connection connection = null;

    public NetDeviceDAO() {
        connection = DAOConnection.create_connection();
    }

    public void showAllRecords() throws SQLException {
        ResultSet resultSet;
        try (Statement statement = connection.createStatement()) {
            // Create and execute a SELECT SQL statement.
            resultSet = statement.executeQuery(VIEW_NETDEVICE_QUERY);
            // Print results from select statement
            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " " + resultSet.getString(3));
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void insertRecords(List<NetDevice> listOfData) throws SQLException {
        {
            int res;
            try (Statement statement = connection.createStatement()) {
                for (NetDevice data : listOfData) {
                    String queryParam = "(" + data.getId() + ", '" + data.getMac() +
                            "', '" + data.getDevice() + "', '" + data.getParent_device() + "'," +
                            " " + data.getVlan_id() + ", '" + data.getIp() + "', '" + data.getNetmask() + "'," +
                            " '" + data.getIpv6() + "', " + data.getNat_enabled() + "," +
                            " '" + data.getOwner() + "', " + data.getDevice_type() + ", '" + NetDevice.getNms_id() + "')";

                    res = statement.executeUpdate(INSERT_NETDEVICE_QUERY + queryParam);
                    if (res != 0) {
                        System.out.println("netdevice ----:" + data.getId() + " successfully polled.!");
                    }
                }
            } catch (SQLException e) {
                connection.close();
                e.printStackTrace();
            }
        }
    }

    public void deleteRecords() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(DELETE_ALL_NETDEVICE_QUERY);
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void pollRecords(List<NetDevice> listOfData) throws SQLException, InterruptedException {
        deleteRecords();
        Thread.sleep(300); // 300 millsec interval between delete and insert operation
        insertRecords(listOfData);
        //showAllRecords();
    }
}
