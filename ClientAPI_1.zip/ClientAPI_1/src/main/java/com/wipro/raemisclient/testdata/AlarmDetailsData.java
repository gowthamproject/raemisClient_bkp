package com.wipro.raemisclient.testdata;

public class AlarmDetailsData {

    public static final String DATA = "[{'id' : 2, 'start_time':'2023-08-02 21:49:32', 'severity':'critical', 'obj_class':'test class'," +
            "'obj_id':'testid', 'alarm_identifier':'', 'event_type':'', 'probable_cause':'raemis', 'specific_problem':'', 'add_text':'critical data'," +
            "'internal_id':3, 'acknowleded':0}, {'id' : 3, 'start_time':'2023-03-22 12:22:11', 'severity':'warning', 'obj_class':'test class 2'," +
            "'obj_id':'testid 2', 'alarm_identifier':'', 'event_type':'', 'probable_cause':'raemis', 'specific_problem':'', 'add_text':'warning data'," +
            "'internal_id':5, 'acknowledge':1}]";
}
