package com.wipro.raemisclient.model;

import com.wipro.raemisclient.common.Constants;

public class Subscriber {

    private int id;
    private String imsi;
    private String tmsi;
    private String ptmsi;
    private String imei;
    private String msisdn;
    private static String nmd_id = Constants.NMS_ID;

    private String sip_client_attachment;

    private String mno_attachment;

    private String local_ps_attachment;

    private String mno_ps_attachment;
    private String domain;
    private String name;

    public int getId() {
        return id;
    }

    public String getImsi() {
        return imsi;
    }

    public String getTmsi() {
        return tmsi;
    }

    public String getPtmsi() {
        return ptmsi;
    }

    public String getImei() {
        return imei;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public String getSip_client_attachment() {
        return sip_client_attachment;
    }

    public String getMno_attachment() {
        return mno_attachment;
    }

    public String getLocal_ps_attachment() {
        return local_ps_attachment;
    }

    public String getMno_ps_attachment() {
        return mno_ps_attachment;
    }

    public String getDomain() {
        return domain;
    }

    public String getName() {
        return name;
    }

    public static String getNmd_id() {
        return nmd_id;
    }
}
