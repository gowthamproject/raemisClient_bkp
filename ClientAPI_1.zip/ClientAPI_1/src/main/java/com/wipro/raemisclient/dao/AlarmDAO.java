package com.wipro.raemisclient.dao;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;
import com.wipro.raemisclient.model.Alarm;
import com.wipro.raemisclient.model.GNodeB;
import com.wipro.raemisclient.testdata.AlarmDetailsData;

import java.io.StringReader;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.List;

public class AlarmDAO implements DAOInterface<Alarm> {

    private static final String DELETE_ALL_ALARMS_QUERY = "DELETE FROM alarmdetails";
    private static final String INSERT_ALARMS_QUERY = "INSERT INTO alarmdetails VALUES";
    private static final String VIEW_ALARMS_QUERY = "SELECT * FROM alarmdetails";
    private static Connection connection = null;
    private static final String INSERT_GNB_QUERY = "INSERT INTO gnb VALUES";



    public AlarmDAO() {
        connection = DAOConnection.create_connection();
    }

    public void showAllRecords() throws SQLException {
        ResultSet resultSet;
        try (Statement statement = connection.createStatement()) {
            // Create and execute a SELECT SQL statement.
            resultSet = statement.executeQuery(VIEW_ALARMS_QUERY);
            // Print results from select statement
            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " " + resultSet.getString(3));
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void insertRecords(List<Alarm> listOfData) throws SQLException {
        int res;
        try (Statement statement = connection.createStatement()) {
            for (Alarm data : listOfData) {
                String queryParam = "(" + data.getId() + ", '" + data.getStart_time() +
                        "', '" + data.getSeverity() + "', '" + data.getObj_class() + "'," +
                        " '" + data.getObj_id() + "', '" + data.getAlarm_identifier() + "', '" + data.getEvent_type() + "'," +
                        " '" + data.getProbable_cause() + "', '" + data.getSpecific_problem() + "'," + " '" + data.getAdd_text() + "'," + data.getInternal_id() + "," +
                        data.getAcknowledge() + ", '" + Alarm.getNms_id() + "')";
                //String test = "(5,'2022-07-05 21:49:25', 'major', 'objclasstest', 'objobjtets', '','','probabletest','specifictest','addtexttest', 10, 7 )";

                res = statement.executeUpdate(INSERT_ALARMS_QUERY + queryParam);
                if (res != 0) {
                    System.out.println("alarm id ----:" + data.getId() + " successfully polled.!");
                }
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void deleteRecords() throws SQLException {
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(DELETE_ALL_ALARMS_QUERY);
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public void pollRecords(List<Alarm> listOfData) throws SQLException, InterruptedException {
        insertRecords(listOfData);
    }

    public void insertRecord(List<GNodeB> listOfData) throws SQLException {
        int res;
        try (Statement statement = connection.createStatement()) {
            for (GNodeB data : listOfData) {
                String queryParam = "('" + data.getName() + "', '" + data.getPlmn_id() +
                        "', " + data.getGnb_id() + ", " + data.getTac() + "," +
                        " '" + data.getSctp_address() + "', '" + GNodeB.NMS_ID + "')";

                res = statement.executeUpdate(INSERT_GNB_QUERY + queryParam);
                if (res != 0) {
                    System.out.println("gnb id ----:" + data.getGnb_id() + " successfully polled.!");
                }
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws SQLException, NoSuchAlgorithmException, KeyManagementException {
        AlarmDAO obj = new AlarmDAO();
        try {
            /*JsonReader reader = new JsonReader(new StringReader(AlarmDetailsData.DATA.trim()));
            reader.setLenient(true);
            Alarm[] alarmDetaiils = new Gson().fromJson(reader, Alarm[].class);
            obj.pollRecords(Arrays.asList(alarmDetaiils));*/
            obj.showAllRecords();

        } catch (Exception e) {
            connection.close();
            e.printStackTrace();
        }
    }
}