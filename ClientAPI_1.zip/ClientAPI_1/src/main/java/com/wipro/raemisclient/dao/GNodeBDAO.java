package com.wipro.raemisclient.dao;

import com.wipro.raemisclient.model.GNodeB;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class GNodeBDAO implements DAOInterface<GNodeB> {
    private static final String DELETE_ALL_GNB_QUERY = "DELETE FROM gnb";
    private static final String INSERT_GNB_QUERY = "INSERT INTO gnb VALUES";
    private static final String VIEW_GNB_QUERY = "SELECT * FROM gnb";
    private static Connection connection = null;

    public void GNodeB() {
        connection = DAOConnection.create_connection();
    }

    @Override
    public void showAllRecords() throws SQLException {

        ResultSet resultSet;
        try (Statement statement = connection.createStatement()) {
            // Create and execute a SELECT SQL statement.
            resultSet = statement.executeQuery(VIEW_GNB_QUERY);
            // Print results from select statement
            while (resultSet.next()) {
                System.out.println(resultSet.getString(2) + " " + resultSet.getString(3));
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }


    }

    @Override
    public void insertRecords(List<GNodeB> listOfData) throws SQLException {
        int res;
        try (Statement statement = connection.createStatement()) {
            for (GNodeB data : listOfData) {
                String queryParam = "('" + data.getName() + "', '" + data.getPlmn_id() +
                        "', " + data.getGnb_id() + ", " + data.getTac() + "," +
                        " '" + data.getSctp_address() + "', '" + GNodeB.NMS_ID + "')";

                res = statement.executeUpdate(INSERT_GNB_QUERY + queryParam);
                if (res != 0) {
                    System.out.println("gnb id ----:" + data.getGnb_id() + " successfully polled.!");
                }
            }
        } catch (SQLException e) {
            connection.close();
            e.printStackTrace();
        }
    }

    @Override
    public void deleteRecords() throws SQLException {

    }

    @Override
    public void pollRecords(List<GNodeB> listOfData) throws SQLException, InterruptedException {
        insertRecords(listOfData);
    }
}
