package com.wipro.raemisclient.common;

public class Constants {

    public static final String NMS_ID = "Raemis";
    public static final String USERNAME = "raemis";
    public static final String PASSWORD = "Test@1234";

    // ----------------- Endpoint Constants --------------
    public static final String RAEMIS_ENDPOINT = "https://20.163.176.87";
    public static final String SESSION_URL = RAEMIS_ENDPOINT + "/api/session";
    public static final String ALARM_URL = RAEMIS_ENDPOINT + "/api/alarm";
    public static final String SUBSCRIBER_URL = RAEMIS_ENDPOINT + "/api/subscriber";
    public static final String NETDEVICE_URL = RAEMIS_ENDPOINT + "/api/net_device";
    public static final String MGW_CTRL_FLOW_STATS_URL = RAEMIS_ENDPOINT + "/api/mgw_ctrl_flow_stats";


    // ----------------- Operation Constants --------------
    public static final String ALARM = "Alarm";
    public static final String SUBSCRIBER = "Subscriber";
    public static final String NETDEVICE = "NetDevice";
    public static final String THROUGHPUT = "NetDevice";

    // ----------------- Throughput Constants --------------

    public static final String UP_LINK = "0";
    public static final String DOWN_LINK = "1";
    public static final String _5G = "SMF";
    public static final String DIRECTION[] = {UP_LINK, DOWN_LINK};


    //--------------- Poll Interval Constants ---------------

    public static final int POLL_INTERVAL = 5000;

    public static final String[] SEVIRITY = {"Critical", "Major", "Warning", "Minor"};

}
