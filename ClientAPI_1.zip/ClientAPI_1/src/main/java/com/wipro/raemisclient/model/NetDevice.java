package com.wipro.raemisclient.model;

public class NetDevice {

    private int id;
    private String mac;
    private String device;
    private String parent_device;
    private int vlan_id;
    private String ip;
    private String netmask;
    private String ipv6;
    private int nat_enabled;
    private String owner;
    private int device_type;
    private static String nms_id;

    public int getId() {
        return id;
    }

    public String getMac() {
        return mac;
    }

    public String getDevice() {
        return device;
    }

    public String getParent_device() {
        return parent_device;
    }

    public int getVlan_id() {
        return vlan_id;
    }

    public String getIp() {
        return ip;
    }

    public String getNetmask() {
        return netmask;
    }

    public String getIpv6() {
        return ipv6;
    }

    public int getNat_enabled() {
        return nat_enabled;
    }

    public String getOwner() {
        return owner;
    }

    public int getDevice_type() {
        return device_type;
    }

    public static String getNms_id() {
        return nms_id;
    }
}
